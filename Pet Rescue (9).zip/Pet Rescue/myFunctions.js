/*Student's First and Last Name
Current Date
My Function List
*/

//Thank you alert
function tyAlert() {
alert("Thank you for your interest in our mission of Pet Rescue Club. We will contact you soon.");
}



